# 《活侠传》战斗加速与重复敌人跳过 1.1.0 — 纯运行安装包

适配 Steam Build 26237817，Unity 2020.3.49f1，Windows x64 Mono。
本包不含游戏本体、游戏程序集、任何人的存档／胜利记录／配置、日志、源码或测试数据。

## 首次安装／卸载后的重新安装

1. 先退出游戏。
2. 把压缩包里的整个 MortalFastCombat 文件夹解压到游戏目录，与 Mortal.exe 同级。
3. 在游戏目录打开 PowerShell，执行：

```powershell
.\MortalFastCombat\Install.ps1
```

4. 正常从 Steam 启动游戏。首次启动自动生成默认配置，不继承打包者的任何记录。

安装脚本先检查游戏指纹和目标文件；已有加载器或同名文件时会停止，不覆盖其他模组。
若已安装本模组、且保留了原安装清单，可执行 .\MortalFastCombat\Update.ps1 更新，保留自己的配置和记录。
若已通过其他模组安装 BepInEx 5，请只把包内 dist/MortalFastCombat.dll 放入游戏的
BepInEx/plugins/MortalFastCombat/，并确保 BepInEx/config/BepInEx.cfg 的
[Chainloader] 下有 HideManagerGameObject = true。手动安装不产生本包的卸载清单，勿使用本包卸载脚本删除其他模组的加载器。

## 使用

- 开启游戏原有的“快速战斗”，点击左上角设置，选择 2／4／8 倍，默认 4 倍。
- 默认开启 Buff 空等待压缩和“精简战斗提示”；保留角色出招与必要对话。
- 同一周目正常击败过的相同普通敌人，之后在首回合可手动“跳过并获胜”。
- 从安装本版后开始记录；不推测以前的胜利。条件结算、剧情事件及无法完整识别的战斗不能跳过。
- 新游戏独立记录；未知旧存档可在战斗设置中手动关联同一周目。
- 关闭原快速战斗停止加速与提示压缩；跳过按钮受模组总开关及独立选项控制。
- 只适用于回合制单挑，剧情、养成和即时制群战保持原行为。

运行时生成的文件：
- BepInEx/config/local.legendofmortal.fastcombat.cfg：自己的设置。
- MortalFastCombat/data/<用户>/history-*.json：自己的周目和胜利记录。
- BepInEx/LogOutput.log：运行日志。
以上文件均未包含在本安装包中。

## 卸载

退出游戏后，在游戏目录 PowerShell 中执行：

```powershell
.\MortalFastCombat\Uninstall.ps1 -WhatIf
.\MortalFastCombat\Uninstall.ps1
```

卸载按安装时生成的清单核对哈希；保留独立胜利记录、其他插件使用的共享加载器及已改动的运行库。
原游戏 DLL 不会被替换。安装后如游戏更新导致指纹不匹配，增强功能会停用。

SHA256SUMS.txt 列出包内文件校验值；第三方组件与许可证见 THIRD_PARTY.md 和 licenses/。
