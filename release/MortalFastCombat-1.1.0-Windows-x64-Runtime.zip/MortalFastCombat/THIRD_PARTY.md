# Third-party components

The loader binaries are copied byte-for-byte from the official Windows x64 BepInEx 5.4.23.6 release.
Only a clean, game-specific BepInEx.cfg is supplied: HideManagerGameObject = true.
No game assemblies or personal data are distributed.

- BepInEx (MIT): https://github.com/BepInEx/BepInEx/releases/tag/v5.4.23.6
  Corresponding source: https://github.com/BepInEx/BepInEx/tree/v5.4.23.6
- HarmonyX (MIT): https://github.com/BepInEx/HarmonyX
- MonoMod (MIT): https://github.com/MonoMod/MonoMod
- Mono.Cecil (MIT): https://github.com/jbevain/cecil
- UnityDoorstop 4.6.0 (LGPL-2.1): https://github.com/NeighTools/UnityDoorstop/tree/v4.6.0

Original license texts are included under licenses/. Third-party binaries are unmodified;
their licenses and copyright notices apply independently of this mod.
